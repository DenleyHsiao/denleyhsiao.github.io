#RubyCppTest
  Through two invoke method to test ruby invoke cpp function.

###RiceTest

  use rice invoke cpp's test, Enter RiceTest directory, then run command `./autogen.sh`

###SwigTest

  use swig invoke cpp's test, Enter SwigTest directory, then run command `./autogen.sh`
