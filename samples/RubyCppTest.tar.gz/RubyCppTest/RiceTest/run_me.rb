require_relative 'example'

a, b = 1, 1
puts "NOTICE: Result will auto increase 1"
puts "#{a} + #{b} = #{Example.new.add(a, b)}"