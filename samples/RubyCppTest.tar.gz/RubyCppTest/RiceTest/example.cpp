#include "rice/Class.hpp"
#include "my_math.h"

using namespace Rice;

//函数名格式：必须是"Init_当前文件名"
extern "C" void Init_example()
{
  //Test为最终RUBY看到的类名
  Class tmp_ = define_class("Example")
    .define_method("add", &add);
}