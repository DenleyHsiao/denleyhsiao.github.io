require 'mkmf-rice'
create_makefile('example')