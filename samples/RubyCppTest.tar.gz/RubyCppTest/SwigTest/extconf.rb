require 'mkmf'
create_makefile('example')
