#! /bin/sh

if [ -e Makefile ]; then
  make clean
  rm -f *_wrap.*
  rm -f Makefile
fi

if [ $# -eq 1 ] && [ $1 == "clean" ]; then
  exit
elif [ $# -ge 1 ]; then
  echo "Usage: $0 [clean]"
  echo "  - [no args]: clean temp files, then build and run test"
  echo "  - clean: only clean temp files"
  exit
fi

swig -ruby example.i
ruby extconf.rb
make
ruby run_me.rb
