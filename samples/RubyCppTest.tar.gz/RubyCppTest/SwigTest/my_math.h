#ifndef __MY_MATH_H__
#define __MY_MATH_H__

extern "C"
{
  extern int add(int a, int b);
}

#endif